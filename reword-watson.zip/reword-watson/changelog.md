# Changelog

All notable changes to this project will be documented in this file.

## [0.0.1]

- Initial app working with Tailwind & NextJS

## [0.0.2]

- Rebuild with plain ReactJS
- Added ability to be run with `docker-compose`
