export enum PROFESSION {
  DIRECTOR = 'Director',
  MANAGER = 'Manager',
  TECHNICAL = 'Technical',
  HR = 'Human Resources',
}
