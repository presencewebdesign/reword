import Home from './Home/Home';
import NotFound from './NotFound/NotFound';

export { Home, NotFound };
