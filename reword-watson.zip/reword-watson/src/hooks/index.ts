import { useSiteTitle } from './useSiteTitle';

export { useSiteTitle };
