export enum ROUTES {
  HOME = '/',
  ANY = '*',
}
