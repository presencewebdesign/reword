# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

- Feature: Add new functionality
- Fix: Correct issue with component
- Update: Update dependency to version x.y.z
- Docs: Update documentation

## [1.0.0] - 2024-03-18

- Initial release
